create database dogs;
use dogs;


create table rece(
    id int auto_increment not null,
    dogsname varchar(50) null,
    dogscolor varchat(50) null,
    age int null,
    primary key(id)
);

select * from race;
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const port = 5000;

// Necessário para obter __dirname em ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configurar a pasta 'public' como estática
app.use(express.static(path.join(__dirname, 'public')));

// Exemplo de rota que redireciona para um arquivo HTML estático
app.get('/teste2', (req, res) => {
  res.redirect('/teste.html');
});

// Inicia o servidor
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
